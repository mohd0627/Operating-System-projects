# course-reader
This program loads students, courses, assignments and scores data from simple-data.txt file
  and allows the user to perform queries on the loaded data from a command line interface.
